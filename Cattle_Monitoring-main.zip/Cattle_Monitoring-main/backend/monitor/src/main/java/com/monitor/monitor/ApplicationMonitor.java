package com.monitor.monitor;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class ApplicationMonitor {
	public static void main(String[] args) {
		SpringApplication.run(ApplicationMonitor.class, args);
	}
}
